<p>Êtes vous sûr?
<form method="post">

    <input class="btn btn-lg btn-success" type="submit" name="supprimer" value="Supprimer" />

    <input class="btn btn-lg btn-error" type="submit" name="annuler" value="Annuler" />
</form>