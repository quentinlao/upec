<?php

require("loader.php");

/* Pour que les gens co peuvent voir les pages public
if ($idm->hasIdentity()) {
    http_response_code(403);
    echo "Error: User already authenticated.";
    exit();
};
*/