<p>Êtes vous sûr?
<form method="post">
    <input type="submit" name="supprimer" value="Supprimer">
    <input type="submit" name="annuler" value="Annuler">
</form>