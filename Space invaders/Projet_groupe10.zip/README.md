<h1>Space invaders</h1>
<h2>Fonctionnement</h2>
<h3>Les touches :</h3>
<h4>Les 4 flèches pour se déplacer de case en case.</h4>
<h4>Les z, q, s et d pour déplacer de 5 cases dans une certaine direction.</h4>
<h4>B pour une bombe.</h4>
<h2>Les limites : ...</h2>
<h2>Les problèmes/solutions : ...</h2>