</div>
</div>
<div class="clear"></div>
<footer>

    <div class="container">
        <div id="information">
            <h4>Informations</h4>
            <ul>
                <li ><a href="<?php echo $path ;?>index.php">Accueil</a></li>
                <li ><a href="<?php echo $path ;?>plandusite.php">Plan du site</a></li>
                <li >Exemple de lien </li>
            </ul>
        </div>
        <div id="chronologie">
            <h4>Documents</h4>
            <ul>
                <li ><a href="<?php echo $path ;?>bootstrap/css/img/plan.png">Schéma du site</a></li>
                <img src="<?php echo $path ;?>bootstrap/css/img/logo.png"/>
            </ul>
        </div>
        <div id="contact">
            <h4>Contact</h4>
            <p>Admin username<br>
                Projet numéro : 7 <br>
                Description : Gestion des participations <br>
                N°étudiant : u123456789<br>
                Email : admin.username@etu.u-pec.fr</p>
        </div>
        <div id="descript">
            <h4>Descriptions</h4>
            <p>  <strong><u>Gestion des participations : <br></u></strong
                ><br>Le but de ce projet est de créer un système d’information pour la gestion des participations.</p>

        </div>
        <div class="clear"></div>
        <p type="credit">Events - Information | 2017 </p>
    </div>
</footer>
</body>

</html>