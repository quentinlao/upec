<?php
$title="Plan du site";
$path = "";
require($path."auth/EtreInvite.php");
include($path."header.php");

?>
<h1><?php echo $title;?></h1>
<img src="bootstrap/css/img/plan.png" alt="Chania">
<?php require('footer.php');?>
