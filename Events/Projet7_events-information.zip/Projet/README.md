<h1>Attention le site web : Events - Information</h1>
<h2>Mettre les bons identifiants dans le db_config.php à la racine.</h2>
<h3>**Rappel ** $hostname;$dbname; $username;$password;</h3>
<h2>Attention dans le dossier Auth, il faut aussi mettre les bonnes redirections dans le fichier config.php</h2>
<h3>**Rappel ** "login",   "logout" ,   "adduser",  "root"</h3>
