#include <stdlib.h>

int main(){
	system("xterm -geometry 102x54 -e ./projet");
	return 0;
}
